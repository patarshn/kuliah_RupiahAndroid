package com.android.rupiah.sayafragmentcontent;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.android.rupiah.R;

public class FaqActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faq);
    }
}
